<div align="center">
    <h6>
        <a href="./">
            <picture>
                <source type="image/svg+xml" media="(prefers-color-scheme: dark)" srcset="https://assets.chatgptjs.org/images/icons/earth/white/icon32.svg?v=e638eac">
               <img height=14 src="https://assets.chatgptjs.org/images/icons/earth/black/icon32.svg?v=e638eac">
            </picture>
        </a>
        English |
        <a href="https://docs.chatgptjs.org/zh-cn/SECURITY.md">简体中文</a> |
        <a href="https://docs.chatgptjs.org/zh-tw/SECURITY.md">繁體中文</a> |
        <a href="https://docs.chatgptjs.org/ja/SECURITY.md">日本</a> |
        <a href="https://docs.chatgptjs.org/ko/SECURITY.md">한국인</a> |
        <a href="https://docs.chatgptjs.org/hi/SECURITY.md">हिंदी</a> |
        <a href="https://docs.chatgptjs.org/ne/SECURITY.md">नेपाली</a> |
        <a href="https://docs.chatgptjs.org/vi/SECURITY.md">Việt</a>
    </h6>
</div>

# Security Policy

If you find a vulnerability, please email <security@kudoai.com>.
