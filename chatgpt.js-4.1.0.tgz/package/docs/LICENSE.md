<div align="center">
    <h6>
        <a href="docs/">
            <picture>
                <source type="image/svg+xml" media="(prefers-color-scheme: dark)" srcset="https://assets.chatgptjs.org/images/icons/earth/white/icon32.svg?v=e638eac">
               <img height=14 src="https://assets.chatgptjs.org/images/icons/earth/black/icon32.svg?v=e638eac">
            </picture>
        </a>
        English |
        <a href="docs/zh-cn/LICENSE.md">简体中文</a> |
        <a href="docs/zh-tw/LICENSE.md">繁體中文</a> |
        <a href="docs/ja/LICENSE.md">日本</a> |
        <a href="docs/ko/LICENSE.md">한국인</a> |
        <a href="docs/hi/LICENSE.md">हिंदी</a> |
        <a href="docs/ne/LICENSE.md">नेपाली</a> |
        <a href="docs/vi/LICENSE.md">Việt</a>
    </h6>
</div>

# MIT License

**Copyright © 2023–2026 [KudoAI](https://github.com/KudoAI) & [contributors](.#-contributors).**

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
