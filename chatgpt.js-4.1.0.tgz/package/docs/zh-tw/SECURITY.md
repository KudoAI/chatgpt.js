<div align="center">
    <h6>
        <a href="../">
            <picture>
                <source type="image/svg+xml" media="(prefers-color-scheme: dark)" srcset="https://assets.chatgptjs.org/images/icons/earth/white/icon32.svg?v=e638eac">
               <img height=14 src="https://assets.chatgptjs.org/images/icons/earth/black/icon32.svg?v=e638eac">
            </picture>
        </a>
        繁體中文 |
        <a href="../SECURITY.md">English</a> |
        <a href="../zh-cn/SECURITY.md">简体中文</a> |
        <a href="../ja/SECURITY.md">日本</a> |
        <a href="../ko/SECURITY.md">한국인</a> |
        <a href="../hi/SECURITY.md">हिंदी</a> |
        <a href="../ne/SECURITY.md">नेपाली</a> |
        <a href="../vi/SECURITY.md">Việt</a>
    </h6>
</div>

# 安全策略

如果您發現漏洞，請發送電子郵件至 <security@kudoai.com>。
