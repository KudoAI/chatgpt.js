<div align="center">
    <h6>
        <a href="../">
            <picture>
                <source type="image/svg+xml" media="(prefers-color-scheme: dark)" srcset="https://assets.chatgptjs.org/images/icons/earth/white/icon32.svg?v=e638eac">
               <img height=14 src="https://assets.chatgptjs.org/images/icons/earth/black/icon32.svg?v=e638eac">
            </picture>
        </a>
        简体中文 |
        <a href="../LICENSE.md">English</a> |
        <a href="../zh-tw/LICENSE.md">繁體中文</a> |
        <a href="../ja/LICENSE.md">日本</a> |
        <a href="../ko/LICENSE.md">한국인</a> |
        <a href="../hi/LICENSE.md">हिंदी</a> |
        <a href="../ne/LICENSE.md">नेपाली</a> |
        <a href="../vi/LICENSE.md">Việt</a>
    </h6>
</div>

# MIT 许可证

版权所有 © 2023–2026 [KudoAI](https://github.com/KudoAI) & [贡献者](.#-贡献者)

特此免费向任何获得副本的人授予许可本软件和相关文档文件（『软件』），处理在软件中不受限制，包括但不限于权利使用、复制、修改、合并、发布、分发、再许可和/或出售该软件的副本，并允许该软件是提供这样做，但须满足以下条件：

上述版权声明和本许可声明应包含在所有软件的副本或重要部分。

本软件『按原样』提供，不提供任何形式的明示或保证暗示的，包括但不限于适销性保证，适用于特定目的和非侵权。 在任何情况下都不得作者或版权持有人对任何索赔、损害或其他责任，无论是在合同、侵权或其他方面的行为中，由以下原因引起，出于或与软件或使用或其他交易有关软件。
