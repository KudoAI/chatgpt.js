<div align="center">
    <h6>
        <a href="../">
            <picture>
                <source type="image/svg+xml" media="(prefers-color-scheme: dark)" srcset="https://assets.chatgptjs.org/images/icons/earth/white/icon32.svg?v=e638eac">
               <img height=14 src="https://assets.chatgptjs.org/images/icons/earth/black/icon32.svg?v=e638eac">
            </picture>
        </a>
        नेपाली |
        <a href="../SECURITY.md">English</a> |
        <a href="../hi/SECURITY.md">हिंदी</a> |
        <a href="../zh-cn/SECURITY.md">简体中文</a> |
        <a href="../zh-tw/SECURITY.md">繁體中文</a> |
        <a href="../ja/SECURITY.md">日本</a> |
        <a href="../ko/SECURITY.md">한국인</a> |
        <a href="../vi/SECURITY.md">Việt</a>
    </h6>
</div>

# सुरक्षा नीति

यदि तपाईंले कुनै जोखिम फेला पार्नुभयो भने, कृपया <security@kudoai.com> मा इमेल गर्नुहोस्।
